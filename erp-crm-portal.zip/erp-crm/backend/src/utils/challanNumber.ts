import { prisma } from "../prismaClient";

// Generates challan numbers like CH-2026-000001, scoped per calendar year.
// Uses count of challans created this year as the sequence source; for a
// production system under high concurrency you'd want a DB sequence instead,
// but this is safe enough for the assignment's scale and is documented as
// a known limitation in the README.
export async function generateChallanNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const startOfYear = new Date(`${year}-01-01T00:00:00.000Z`);
  const endOfYear = new Date(`${year + 1}-01-01T00:00:00.000Z`);

  const countThisYear = await prisma.challan.count({
    where: {
      createdAt: {
        gte: startOfYear,
        lt: endOfYear,
      },
    },
  });

  const sequence = String(countThisYear + 1).padStart(6, "0");
  return `CH-${year}-${sequence}`;
}
